import React, { useState } from 'react';
import { motion } from 'motion/react';
import {
  ShoppingCart,
  Search,
  Menu,
  X,
  Brain,
  CircleDollarSign,
  Truck,
  Star,
  ArrowRight,
  CheckCircle2,
  ChevronRight,
  User,
  Heart
} from 'lucide-react';

const CATEGORIES = [
  { name: 'Kitchen Tools', image: 'https://images.unsplash.com/photo-1556910103-1c02745a872f?auto=format&fit=crop&q=80&w=800' },
  { name: 'Home Essentials', image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&q=80&w=800' },
  { name: 'Bathroom Organisers', image: 'https://images.unsplash.com/photo-1552322689-104ca9f8098e?auto=format&fit=crop&q=80&w=800' },
  { name: 'Daily Gadgets', image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&q=80&w=800' },
];

const PRODUCTS = [
  {
    id: 1,
    name: 'Rechargeable Automatic Self Stirring Coffee Mug',
    price: 24.99,
    originalPrice: 39.99,
    rating: 4.8,
    reviews: 124,
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&q=80&w=800',
    badge: 'Best Seller',
  },
  {
    id: 2,
    name: 'Bathroom Shelf for Shower & Toilet Storage',
    price: 19.99,
    originalPrice: 29.99,
    rating: 4.9,
    reviews: 89,
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=800',
    badge: 'Space Saver',
  },
  {
    id: 3,
    name: '3-in-1 Avocado Cutting & Pitting Tool',
    price: 12.99,
    originalPrice: 18.99,
    rating: 4.7,
    reviews: 256,
    image: 'https://images.unsplash.com/photo-1523049673857-eb18f1d7b578?auto=format&fit=crop&q=80&w=800',
    badge: 'Kitchen Essential',
  },
  {
    id: 4,
    name: 'Smart Robot Vacuum & Mop Cleaner',
    price: 149.99,
    originalPrice: 249.99,
    rating: 4.6,
    reviews: 42,
    image: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?auto=format&fit=crop&q=80&w=800',
    badge: 'Sale',
  }
];

const FEATURES = [
  {
    icon: Brain,
    title: 'Purpose-Driven Products',
    description: 'Hand-picked solutions that actually work and solve real everyday problems.',
  },
  {
    icon: CircleDollarSign,
    title: 'Transparent, Fair Pricing',
    description: 'Priced lower than anywhere else online. No hidden fees, just great value.',
  },
  {
    icon: Truck,
    title: 'Reliable Worldwide Delivery',
    description: 'Fast, trackable shipping straight to your door, wherever you are.',
  },
];

export default function App() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900">
      {/* Announcement Bar */}
      <div className="bg-blue-600 text-white text-sm font-medium py-2 px-4 text-center">
        Free Worldwide Shipping on Orders Over $50! Shop Now
      </div>

      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Mobile menu button */}
            <div className="flex items-center md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="text-slate-500 hover:text-slate-900 focus:outline-none"
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>

            {/* Logo */}
            <div className="flex-shrink-0 flex items-center justify-center flex-1 md:flex-none md:justify-start">
              <a href="#" className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2">
                <div className="bg-blue-600 text-white p-1.5 rounded-lg">
                  <CheckCircle2 className="h-5 w-5" />
                </div>
                Problems<span className="text-blue-600">Solved</span>™
              </a>
            </div>

            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <a href="#" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Shop All</a>
              <a href="#" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Kitchen</a>
              <a href="#" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Bathroom</a>
              <a href="#" className="text-slate-600 hover:text-blue-600 font-medium transition-colors">Gadgets</a>
            </div>

            {/* Icons */}
            <div className="flex items-center space-x-4 md:space-x-6">
              <button className="text-slate-500 hover:text-blue-600 transition-colors hidden sm:block">
                <Search className="h-5 w-5" />
              </button>
              <button className="text-slate-500 hover:text-blue-600 transition-colors hidden sm:block">
                <User className="h-5 w-5" />
              </button>
              <button className="text-slate-500 hover:text-blue-600 transition-colors relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute -top-1.5 -right-1.5 bg-blue-600 text-white text-[10px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  0
                </span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="md:hidden bg-white border-b border-slate-100 px-4 pt-2 pb-4 space-y-1 shadow-lg absolute w-full"
          >
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-slate-900 hover:bg-slate-50">Shop All</a>
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900">Kitchen Tools</a>
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900">Bathroom Organisers</a>
            <a href="#" className="block px-3 py-2 rounded-md text-base font-medium text-slate-600 hover:bg-slate-50 hover:text-slate-900">Daily Gadgets</a>
            <div className="pt-4 flex items-center gap-4 px-3">
              <button className="flex items-center gap-2 text-slate-600"><Search className="h-5 w-5"/> Search</button>
              <button className="flex items-center gap-2 text-slate-600"><User className="h-5 w-5"/> Account</button>
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative bg-slate-50 overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2000')] bg-cover bg-center opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 pb-24 relative z-10">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="inline-block py-1 px-3 rounded-full bg-blue-100 text-blue-700 text-sm font-semibold mb-6 tracking-wide uppercase">
                Zero Hassle Shopping
              </span>
              <h1 className="text-4xl md:text-6xl font-extrabold text-slate-900 tracking-tight mb-6 leading-tight">
                Smart Problem-Solving Gadgets at the <span className="text-blue-600">Best Prices</span>
              </h1>
              <p className="text-lg md:text-xl text-slate-600 mb-10 max-w-2xl mx-auto">
                Discover smart, practical gadgets designed to solve everyday problems. Hand-picked solutions that actually work, priced lower than anywhere else online.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="https://www.problemssolved.shop?sca_ref=10704201.MzpI7iRDXyVdMR3C" target="_blank" rel="noopener noreferrer" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-full font-semibold text-lg transition-all shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2">
                  Shop Solutions <ArrowRight className="h-5 w-5" />
                </a>
                <a href="https://www.problemssolved.shop?sca_ref=10704201.MzpI7iRDXyVdMR3C" target="_blank" rel="noopener noreferrer" className="bg-white hover:bg-slate-50 text-slate-900 border border-slate-200 px-8 py-4 rounded-full font-semibold text-lg transition-all flex items-center justify-center gap-2">
                  Find What You Need
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white border-b border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {FEATURES.map((feature, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="flex flex-col items-center text-center p-6 rounded-2xl hover:bg-slate-50 transition-colors"
              >
                <div className="h-14 w-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
                  <feature.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-3">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 bg-slate-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-10">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Shop by Problem</h2>
              <p className="text-slate-600">Find the right solution faster. No guesswork needed.</p>
            </div>
            <a href="#" className="hidden sm:flex items-center text-blue-600 font-semibold hover:text-blue-700">
              View All Categories <ChevronRight className="h-5 w-5 ml-1" />
            </a>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {CATEGORIES.map((category, index) => (
              <motion.a
                href="#"
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group relative rounded-2xl overflow-hidden aspect-square flex items-end"
              >
                <img 
                  src={category.image} 
                  alt={category.name}
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
                <div className="relative p-6 w-full">
                  <h3 className="text-white font-bold text-lg md:text-xl">{category.name}</h3>
                  <p className="text-white/80 text-sm mt-1 flex items-center opacity-0 group-hover:opacity-100 transition-opacity transform translate-y-2 group-hover:translate-y-0">
                    Explore <ArrowRight className="h-4 w-4 ml-1" />
                  </p>
                </div>
              </motion.a>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Only Useful Products</h2>
            <p className="text-slate-600 max-w-2xl mx-auto text-lg">
              Tested for daily life. We focus on everyday frustrations first and provide simple, practical solutions.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {PRODUCTS.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="group flex flex-col"
              >
                <div className="relative rounded-2xl overflow-hidden mb-4 bg-slate-100 aspect-[4/5]">
                  {product.badge && (
                    <div className="absolute top-3 left-3 z-10 bg-white/90 backdrop-blur-sm text-slate-900 text-xs font-bold px-3 py-1.5 rounded-full shadow-sm">
                      {product.badge}
                    </div>
                  )}
                  <button className="absolute top-3 right-3 z-10 p-2 rounded-full bg-white/90 backdrop-blur-sm text-slate-400 hover:text-red-500 hover:bg-white transition-colors shadow-sm opacity-0 group-hover:opacity-100">
                    <Heart className="h-5 w-5" />
                  </button>
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  
                  {/* Quick Add Button */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
                    <button className="w-full bg-slate-900/90 backdrop-blur-md text-white py-3 rounded-xl font-semibold hover:bg-slate-900 transition-colors flex items-center justify-center gap-2">
                      <ShoppingCart className="h-4 w-4" /> Add to Cart
                    </button>
                  </div>
                </div>

                <div className="flex flex-col flex-grow">
                  <div className="flex items-center gap-1 mb-2">
                    <div className="flex text-yellow-400">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`h-4 w-4 ${i < Math.floor(product.rating) ? 'fill-current' : 'text-slate-300'}`} />
                      ))}
                    </div>
                    <span className="text-xs text-slate-500 font-medium">({product.reviews})</span>
                  </div>
                  <h3 className="text-slate-900 font-semibold mb-2 line-clamp-2 hover:text-blue-600 transition-colors cursor-pointer">
                    {product.name}
                  </h3>
                  <div className="mt-auto flex items-baseline gap-2">
                    <span className="text-lg font-bold text-slate-900">${product.price}</span>
                    <span className="text-sm text-slate-400 line-through">${product.originalPrice}</span>
                    <span className="text-xs font-bold text-green-600 ml-auto bg-green-50 px-2 py-1 rounded-md">
                      Save ${(product.originalPrice - product.price).toFixed(2)}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          
          <div className="mt-12 text-center">
            <button className="inline-flex items-center justify-center px-8 py-4 border-2 border-slate-200 text-slate-900 font-bold rounded-full hover:border-slate-900 transition-colors">
              View All Products
            </button>
          </div>
        </div>
      </section>

      {/* Value Proposition Banner */}
      <section className="bg-slate-900 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl md:text-5xl font-bold mb-6 leading-tight">
                Built to Fix Real<br/>Daily Problems.
              </h2>
              <p className="text-slate-400 text-lg mb-8 max-w-lg">
                We don't just sell gadgets. We sell time, convenience, and peace of mind. Every product in our store is rigorously tested to ensure it actually makes your life easier.
              </p>
              <ul className="space-y-4">
                {[
                  'Curated selection of high-utility items',
                  'Quality tested for durability and performance',
                  '30-day money-back guarantee',
                  '24/7 customer support team'
                ].map((item, i) => (
                  <li key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="h-6 w-6 text-blue-500 flex-shrink-0" />
                    <span className="text-slate-200">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative"
            >
              <div className="aspect-square rounded-3xl overflow-hidden relative">
                <img 
                  src="https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&q=80&w=1000" 
                  alt="Organized kitchen" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-blue-600/20 mix-blend-multiply"></div>
              </div>
              
              {/* Floating badge */}
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl max-w-xs">
                <div className="flex items-center gap-4 mb-2">
                  <div className="flex -space-x-3">
                    <img className="w-10 h-10 rounded-full border-2 border-white" src="https://i.pravatar.cc/100?img=1" alt="User" />
                    <img className="w-10 h-10 rounded-full border-2 border-white" src="https://i.pravatar.cc/100?img=2" alt="User" />
                    <img className="w-10 h-10 rounded-full border-2 border-white" src="https://i.pravatar.cc/100?img=3" alt="User" />
                  </div>
                  <div className="text-slate-900 font-bold">
                    <span className="text-yellow-500">★ 4.9/5</span>
                  </div>
                </div>
                <p className="text-sm text-slate-600 font-medium">Trusted by 10,000+ happy customers worldwide.</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Newsletter & Footer */}
      <footer className="bg-slate-50 pt-20 pb-10 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
            <div className="lg:col-span-2">
              <a href="#" className="text-2xl font-bold tracking-tight text-slate-900 flex items-center gap-2 mb-6">
                <div className="bg-blue-600 text-white p-1.5 rounded-lg">
                  <CheckCircle2 className="h-5 w-5" />
                </div>
                Problems<span className="text-blue-600">Solved</span>™
              </a>
              <p className="text-slate-600 mb-8 max-w-md">
                Join our email list to get exclusive deals, new product announcements, and problem-solving tips delivered straight to your inbox.
              </p>
              <form className="flex gap-2 max-w-md">
                <input 
                  type="email" 
                  placeholder="Enter your email" 
                  className="flex-1 bg-white border border-slate-300 rounded-xl px-4 py-3 text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent"
                  required
                />
                <button type="submit" className="bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-xl font-semibold transition-colors">
                  Subscribe
                </button>
              </form>
            </div>
            
            <div>
              <h4 className="font-bold text-slate-900 mb-6">Shop</h4>
              <ul className="space-y-4">
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">All Products</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Kitchen Tools</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Bathroom Organisers</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Daily Gadgets</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Sale</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-slate-900 mb-6">Support</h4>
              <ul className="space-y-4">
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Track Order</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Shipping Policy</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Returns & Refunds</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">Contact Us</a></li>
                <li><a href="#" className="text-slate-600 hover:text-blue-600 transition-colors">FAQ</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-500 text-sm">
              © {new Date().getFullYear()} Problems Solved™. All rights reserved.
            </p>
            <div className="flex items-center gap-6">
              <a href="#" className="text-slate-500 hover:text-slate-900 text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-slate-500 hover:text-slate-900 text-sm transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
